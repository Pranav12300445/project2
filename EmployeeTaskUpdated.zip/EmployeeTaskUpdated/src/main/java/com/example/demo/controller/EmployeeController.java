package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Employee;
import com.example.demo.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    private EmployeeService service;

    // CREATE Employee
    @PostMapping("/create")
    public String createEmployee(@RequestBody Employee emp) {
        return service.validate(emp);
    }

    // DISPLAY All Employees
    @GetMapping("/display")
    public List<Employee> displayEmployees() {
        return service.getAll();
    }

    // RAISE SALARY
    @PutMapping("/raiseSalary")
    public String raiseSalary(@RequestParam String name,
                              @RequestParam int percentage) {

        return service.raiseSalary(name, percentage);
    }
    
    @GetMapping("/exit")
    public String exit() {
    	return "Thank you so much for using my application";
    }
}