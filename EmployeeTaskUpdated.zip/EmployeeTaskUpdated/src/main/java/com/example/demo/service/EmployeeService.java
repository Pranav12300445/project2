package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepo;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepo repo;
    
    private boolean isValidName(String name) {

        int spaces = 0;

        for(char ch : name.toCharArray()) {

            if(ch == ' ')
                spaces++;

            else if(!Character.isLetter(ch))
                return false;
        }

        return spaces <= 2;
    }

    public String validate(Employee emp) {

        if(!isValidName(emp.getName()))
            return "Name should contain only letters and maximum two spaces.";

        if(emp.getAge()<18 || emp.getAge()>60)
            return "Age should be between 18 and 60.";

        switch(emp.getDesignation().toLowerCase()) {

            case "programmer":
                emp.setSalary(25000);
                break;

            case "manager":
                emp.setSalary(30000);
                break;

            case "tester":
                emp.setSalary(20000);
                break;

            default:
                return "Invalid Designation";
        }

        repo.save(emp);

        return "Employee Created Successfully";
    }

    public List<Employee> getAll() {
        return repo.findAll();
    }

    public String raiseSalary(String name, int percentage) {

        Employee emp = repo.findByName(name);

        if(emp == null) {
            return "Employee Not Found";
        }

        if(percentage < 1 || percentage > 10) {
            return "Percentage should be between 1 and 10";
        }

        double newSalary = emp.getSalary()
                + (emp.getSalary() * percentage / 100.0);

        emp.setSalary(newSalary);

        repo.save(emp);

        return "Salary Updated Successfully";
    }
}